enum Subscription {
  FREE = 'SUBSCRIPTION_FREE',
}

export default Subscription;
