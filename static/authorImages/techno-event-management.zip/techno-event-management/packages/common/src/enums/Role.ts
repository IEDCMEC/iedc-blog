enum Role {
  OWNER = 'ROLE_OWNER',
}

export default Role;
