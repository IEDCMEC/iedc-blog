import React from 'react';

const Navbar = () => {
  return <div className="h-10 font-semibold tracking-wide">Organizaton &gt; Event</div>;
};

export default Navbar;
