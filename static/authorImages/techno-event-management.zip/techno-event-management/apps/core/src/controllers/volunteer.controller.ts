const getEventVolunteers = () => {
  return { message: 'Get all volunteers' };
};

const getEventVolunteerById = () => {
  return { message: 'Get volunteer by id' };
};

export { getEventVolunteers, getEventVolunteerById };
