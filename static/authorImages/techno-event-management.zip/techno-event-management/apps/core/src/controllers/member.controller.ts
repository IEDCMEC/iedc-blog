const getOrganizationMembers = () => {
  return { message: 'Get all members' };
};

const getOrganizationMemberById = () => {
  return { message: 'Get member by id' };
};

export { getOrganizationMembers, getOrganizationMemberById };
