const getVolunteers = async (organizationId: string, eventId: string) => {};
const getVolunteer = async (organizationId: string, eventId: string, userId: string) => {};
