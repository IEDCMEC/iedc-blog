const getEventExtras = async (organizationId: string, eventId: string) => {};

const getEventExtra = async (organizationId: string, eventId: string, extraId: string) => {};

const extraCheckIn = async (organizationId: string, eventId: string, extraId: string) => {};

const extraCheckInStatus = async (organizationId: string, eventId: string, extraId: string) => {};
